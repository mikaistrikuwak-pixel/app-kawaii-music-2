package com.kawaii.music;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Build;
import android.os.IBinder;
import android.webkit.WebView;

import androidx.annotation.Nullable;
import androidx.core.app.NotificationCompat;
import androidx.media.app.NotificationCompat.MediaStyle;
import androidx.media.session.MediaSessionCompat;


public final class MediaService extends Service {
    private static final String CH_ID = "kawaii_music_playback";
    private static final int NOTIF_ID = 2210;
    private static final String A_PLAY = "kw.play";
    private static final String A_PAUSE = "kw.pause";
    private static final String A_PREV = "kw.prev";
    private static final String A_NEXT = "kw.next";
    private static final String A_BACK = "kw.back10";
    private static final String A_FWD = "kw.fwd10";
    private static final String A_CLOSE = "kw.close";
    private static MediaSessionCompat session;
    private static State state = new State();

    static final class State { String title="Kawaii Music", artist="", album=""; byte[] cover; boolean playing; long pos,dur; }

    @Override public void onCreate() {
        super.onCreate();
        createChannel();
        session = new MediaSessionCompat(this, "KawaiiMusic");
        session.setCallback(new MediaSessionCompat.Callback() {
            @Override public void onPlay() { sendJs("play", null); }
            @Override public void onPause() { sendJs("pause", null); }
            @Override public void onSkipToPrevious() { sendJs("prev", null); }
            @Override public void onSkipToNext() { sendJs("next", null); }
            @Override public void onSeekTo(long p) { sendJs("seek", p); }
            @Override public void onStop() { sendJs("stop", null); stopForeground(STOP_FOREGROUND_REMOVE); stopSelf(); }
        });
        session.setActive(true);
    }

    static synchronized void update(Context ctx, String title, String artist, String album, String cover, boolean playing, long pos, long dur) {
        Intent i = new Intent(ctx, MediaService.class).setAction("UPDATE");
        i.putExtra("title", title); i.putExtra("artist", artist); i.putExtra("album", album); i.putExtra("cover", cover); i.putExtra("playing", playing); i.putExtra("pos", pos); i.putExtra("dur", dur);
        if (Build.VERSION.SDK_INT >= 26) ctx.startForegroundService(i); else ctx.startService(i);
    }

    static synchronized void clear(Context ctx) {
        try { if (session != null) session.setActive(false); } catch (Throwable ignored) {}
        ctx.stopService(new Intent(ctx, MediaService.class));
    }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && "UPDATE".equals(intent.getAction())) {
            state.title = safe(intent.getStringExtra("title"), "Kawaii Music");
            state.artist = safe(intent.getStringExtra("artist"), "");
            state.album = safe(intent.getStringExtra("album"), "");
            state.playing = intent.getBooleanExtra("playing", false);
            state.pos = intent.getLongExtra("pos", 0); state.dur = intent.getLongExtra("dur", 0);
            state.cover = decodeCover(intent.getStringExtra("cover"));
            if (Build.VERSION.SDK_INT >= 26) startForeground(NOTIF_ID, buildNotification()); else { ((NotificationManager)getSystemService(NOTIFICATION_SERVICE)).notify(NOTIF_ID, buildNotification()); }
            syncSession();
        } else if (intent != null) handleAction(intent.getAction());
        return START_STICKY;
    }

    private String safe(String s,String d){return s==null?d:s;}

    private byte[] decodeCover(String s) {
        try {
            if (s == null || s.isEmpty()) return null;
            int comma = s.indexOf(',');
            if (s.startsWith("data:") && comma >= 0) {
                if (Build.VERSION.SDK_INT >= 26) return java.util.Base64.getDecoder().decode(s.substring(comma+1));
                return android.util.Base64.decode(s.substring(comma+1), android.util.Base64.DEFAULT);
            }
        } catch (Throwable ignored) {}
        return null;
    }

    private Bitmap coverBitmap() {
        try {
            if (state.cover == null) return null;
            return BitmapFactory.decodeByteArray(state.cover,0,state.cover.length);
        } catch (Throwable ignored) { return null; }
    }

    private Notification buildNotification() {
        Bitmap b = coverBitmap();
        NotificationCompat.Builder n = new NotificationCompat.Builder(this, CH_ID)
                .setSmallIcon(com.kawaii.music.R.drawable.ic_stat_music)
                .setContentTitle(state.title)
                .setContentText(state.artist + (state.album.isEmpty()?"":" • "+state.album))
                .setSubText(state.album)
                .setOnlyAlertOnce(true)
                .setOngoing(state.playing)
                .setShowWhen(false)
                .setColor(0xff79b7ff)
                .setCategory(NotificationCompat.CATEGORY_TRANSPORT)
                .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
                .setContentIntent(openApp())
                .addAction(action(android.R.drawable.ic_media_rew, "Mundur 10 detik", A_BACK))
                .addAction(action(state.playing?android.R.drawable.ic_media_pause:android.R.drawable.ic_media_play, state.playing?"Jeda":"Putar", state.playing?A_PAUSE:A_PLAY))
                .addAction(action(android.R.drawable.ic_media_ff, "Berikutnya", A_NEXT))
                .addAction(action(android.R.drawable.ic_menu_close_clear_cancel, "Tutup", A_CLOSE))
                .setStyle(new MediaStyle().setMediaSession(session.getSessionToken()).setShowActionsInCompactView(0,1,2));
        if (b != null) n.setLargeIcon(b);
        if (state.dur > 0) n.setProgress((int)Math.min(Integer.MAX_VALUE, state.dur/1000L), (int)Math.min(Integer.MAX_VALUE, state.pos/1000L), false);
        return n.build();
    }

    private NotificationCompat.Action action(int icon,String title,String action){
        Intent i=new Intent(this,MediaService.class).setAction(action); PendingIntent p=PendingIntent.getService(this, action.hashCode(), i, PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);return new NotificationCompat.Action.Builder(icon,title,p).build();
    }
    private PendingIntent openApp(){Intent i=getPackageManager().getLaunchIntentForPackage(getPackageName());return PendingIntent.getActivity(this,100,i,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);}

    private void syncSession(){if(session==null)return;long pos=Math.max(0,state.pos),dur=Math.max(0,state.dur);android.support.v4.media.MediaMetadataCompat m=new android.support.v4.media.MediaMetadataCompat.Builder().putString(android.support.v4.media.MediaMetadataCompat.METADATA_KEY_TITLE,state.title).putString(android.support.v4.media.MediaMetadataCompat.METADATA_KEY_ARTIST,state.artist).putString(android.support.v4.media.MediaMetadataCompat.METADATA_KEY_ALBUM,state.album).putLong(android.support.v4.media.MediaMetadataCompat.METADATA_KEY_DURATION,dur).build();session.setMetadata(m);long actions=android.support.v4.media.session.PlaybackStateCompat.ACTION_PLAY|android.support.v4.media.session.PlaybackStateCompat.ACTION_PAUSE|android.support.v4.media.session.PlaybackStateCompat.ACTION_SKIP_TO_NEXT|android.support.v4.media.session.PlaybackStateCompat.ACTION_SKIP_TO_PREVIOUS|android.support.v4.media.session.PlaybackStateCompat.ACTION_SEEK_TO;int st=state.playing?android.support.v4.media.session.PlaybackStateCompat.STATE_PLAYING:android.support.v4.media.session.PlaybackStateCompat.STATE_PAUSED;session.setPlaybackState(new android.support.v4.media.session.PlaybackStateCompat.Builder().setActions(actions).setState(st,pos,1f).build());}

    private void handleAction(String a){if(A_CLOSE.equals(a)){sendJs("stop",null);stopForeground(STOP_FOREGROUND_REMOVE);stopSelf();return;}if(A_PLAY.equals(a))sendJs("play",null);else if(A_PAUSE.equals(a))sendJs("pause",null);else if(A_PREV.equals(a))sendJs("prev",null);else if(A_NEXT.equals(a))sendJs("next",null);else if(A_BACK.equals(a))sendJs("back10",null);else if(A_FWD.equals(a))sendJs("fwd10",null);}

    private void sendJs(String act, @Nullable Long v){WebView w=MainActivityWeb.web(); if(w==null)return;String js="window.__nm&&window.__nm('"+act+"'"+(v==null?"":","+v)+")";w.post(()->w.evaluateJavascript(js,null));}

    private void createChannel(){if(Build.VERSION.SDK_INT>=26){NotificationManager m=getSystemService(NotificationManager.class);NotificationChannel c=new NotificationChannel(CH_ID,"Kawaii Music",NotificationManager.IMPORTANCE_LOW);c.setDescription("Kontrol pemutaran musik dan album");c.setShowBadge(false);m.createNotificationChannel(c);}}
    @Override public void onDestroy(){try{if(session!=null){session.setActive(false);session.release();session=null;}}catch(Throwable ignored){}super.onDestroy();}
    @Nullable @Override public IBinder onBind(Intent intent){return null;}

    // Small indirection keeps the service independent from MainActivity's private WebView field.
    static final class MainActivityWeb { static WebView web(){return MainActivity.getWebView();} }
}
