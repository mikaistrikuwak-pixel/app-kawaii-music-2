package com.kawaii.music;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.res.Configuration;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebSettings;
import android.net.Uri;
import android.os.ParcelFileDescriptor;

import androidx.annotation.Nullable;
import androidx.webkit.WebViewAssetLoader;

import java.io.FileInputStream;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;

public class MainActivity extends Activity {
    private static WebView webView;
    private static MainActivity instance;
    private NativeBridge bridge;
    private WebViewAssetLoader assetLoader;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private boolean pageReady = false;
    private boolean audioPermissionAsked = false;
    private boolean notificationPermissionAsked = false;

    @Override public void onCreate(@Nullable Bundle state) {
        super.onCreate(state);
        instance = this;
        getWindow().setNavigationBarColor(0xffeef6ff);
        bridge = new NativeBridge(this);
        setupWebView();
        requestRuntimeAccess();
    }

    private void setupWebView() {
        webView = new WebView(this);
        webView.setOverScrollMode(WebView.OVER_SCROLL_NEVER);
        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(false);
        s.setBuiltInZoomControls(false);
        s.setDisplayZoomControls(false);
        s.setSupportZoom(false);
        s.setTextZoom(100);
        assetLoader = new WebViewAssetLoader.Builder().addPathHandler("assets", new WebViewAssetLoader.AssetsPathHandler(this)).build();
        webView.addJavascriptInterface(bridge, "KMNative");
        webView.setWebViewClient(new WebViewClient() {
            @Override public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                return intercept(request.getUrl(), request.getRequestHeaders());
            }
            @Override public WebResourceResponse shouldInterceptRequest(WebView view, String url) {
                return intercept(Uri.parse(url), new HashMap<>());
            }
            @Override public void onPageFinished(WebView view, String url) {
                pageReady = true;
                requestRuntimeAccess();
            }
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                return false;
            }
        });
        setContentView(webView);
        webView.loadUrl(NativeBridge.ASSET_BASE + "/assets/www/index.html");
    }

    private WebResourceResponse intercept(Uri uri, Map<String,String> headers) {
        String host = uri.getHost();
        if ("appassets.androidplatform.net".equals(host)) {
            String p = uri.getPath();
            if (p != null && p.startsWith("/media/")) return bridge.openMedia(Uri.decode(p.substring(7)), headers == null ? null : headers.get("Range"));
            if (p != null && p.startsWith("/art/")) return bridge.openAlbumArt(Uri.decode(p.substring(5)));
            return assetLoader.shouldInterceptRequest(uri);
        }
        return null;
    }

    static WebResourceResponse openContent(android.content.ContentResolver cr, Uri uri, String rangeHeader) {
        try {
            String mime = cr.getType(uri);
            if (mime == null) mime = "application/octet-stream";
            ParcelFileDescriptor pfd = cr.openFileDescriptor(uri, "r");
            if (pfd == null) return null;
            long length = pfd.getStatSize();
            long start = 0;
            long end = length > 0 ? length - 1 : -1;
            boolean partial = false;
            if (rangeHeader != null && rangeHeader.startsWith("bytes=") && length > 0) {
                String r = rangeHeader.substring(6).split(",")[0].trim();
                int dash = r.indexOf('-');
                if (dash >= 0) {
                    try { start = Long.parseLong(r.substring(0, dash)); } catch (Exception ignored) {}
                    if (dash < r.length()-1) { try { end = Long.parseLong(r.substring(dash+1)); } catch (Exception ignored) {} }
                    if (start >= length) start = 0;
                    if (end < start || end >= length) end = length - 1;
                    partial = start > 0 || end < length - 1;
                }
            }
            FileInputStream fis = new FileInputStream(pfd.getFileDescriptor());
            long toSkip = start;
            while (toSkip > 0) { long n=fis.skip(toSkip); if(n<=0)break; toSkip-=n; }
            WebResourceResponse r = new WebResourceResponse(mime, null, fis);
            if (partial) {
                r.setStatusCodeAndReasonPhrase(206, "Partial Content");
                Map<String,String> h = new HashMap<>();
                h.put("Accept-Ranges", "bytes");
                h.put("Content-Range", "bytes " + start + "-" + end + "/" + length);
                h.put("Content-Length", String.valueOf(end - start + 1));
                r.setResponseHeaders(h);
            } else if (length > 0) {
                Map<String,String> h = new HashMap<>(); h.put("Content-Length", String.valueOf(length)); h.put("Accept-Ranges", "bytes"); r.setResponseHeaders(h);
            }
            return r;
        } catch (Throwable ignored) { return null; }
    }

    private void requestRuntimeAccess() {
        if (!bridge.hasAudioAccess() && !audioPermissionAsked) {
            audioPermissionAsked = true;
            bridge.requestAudioAccess();
        }
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED && !notificationPermissionAsked) {
            notificationPermissionAsked = true;
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 4102);
        }
    }

    static void rescanWeb() {
        if (instance == null || webView == null || !instance.pageReady) return;
        webView.postDelayed(() -> webView.evaluateJavascript("window.__nativeRescan&&window.__nativeRescan()", null), 150);
    }

    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == 4101) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) rescanWeb();
            else if (webView != null) webView.evaluateJavascript("window.__nativePermissionDenied&&window.__nativePermissionDenied()", null);
        }
    }

    @Override protected void onResume() { super.onResume(); if (pageReady) rescanWeb(); }

    @Override public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack(); else super.onBackPressed();
    }

    static WebView getWebView() { return webView; }

    @Override protected void onDestroy() {
        pageReady=false;
        if (webView != null) { webView.removeJavascriptInterface("KMNative"); webView.destroy(); webView=null; }
        if (instance == this) instance=null;
        super.onDestroy();
    }
}
