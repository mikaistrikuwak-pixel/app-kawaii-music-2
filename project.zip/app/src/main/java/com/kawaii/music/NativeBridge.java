package com.kawaii.music;

import android.Manifest;
import android.app.Activity;
import android.content.ContentResolver;
import android.content.ContentUris;
import android.content.Context;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.provider.MediaStore;
import android.webkit.JavascriptInterface;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public final class NativeBridge {
    static final String ASSET_BASE = "https://appassets.androidplatform.net";
    private static final int REQ_AUDIO = 4101;
    private static final int REQ_NOTIF = 4102;
    private final MainActivity activity;

    NativeBridge(MainActivity activity) { this.activity = activity; }

    private boolean hasAudioPermission() {
        if (Build.VERSION.SDK_INT >= 33) {
            return activity.checkSelfPermission(Manifest.permission.READ_MEDIA_AUDIO) == PackageManager.PERMISSION_GRANTED;
        }
        return activity.checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED;
    }

    @JavascriptInterface public boolean hasAudioAccess() { return hasAudioPermission(); }

    @JavascriptInterface public void requestAudioAccess() {
        activity.runOnUiThread(() -> {
            if (hasAudioPermission()) { MainActivity.rescanWeb(); return; }
            String[] p = Build.VERSION.SDK_INT >= 33 ?
                    new String[]{Manifest.permission.READ_MEDIA_AUDIO} :
                    new String[]{Manifest.permission.READ_EXTERNAL_STORAGE};
            activity.requestPermissions(p, REQ_AUDIO);
        });
    }

    @JavascriptInterface public void requestNotificationAccess() {
        if (Build.VERSION.SDK_INT >= 33) activity.runOnUiThread(() -> activity.requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, REQ_NOTIF));
    }

    @JavascriptInterface public String scanAudio() {
        JSONObject out = new JSONObject();
        try {
            if (!hasAudioPermission()) { out.put("ok", false); out.put("permission", true); return out.toString(); }
            JSONArray tracks = new JSONArray();
            Set<String> seen = new HashSet<>();
            ContentResolver cr = activity.getContentResolver();
            Uri base = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI;
            String[] proj = {
                    MediaStore.Audio.Media._ID,
                    MediaStore.Audio.Media.TITLE,
                    MediaStore.Audio.Media.ARTIST,
                    MediaStore.Audio.Media.ALBUM,
                    MediaStore.Audio.Media.ALBUM_ID,
                    MediaStore.Audio.Media.DURATION,
                    MediaStore.Audio.Media.MIME_TYPE,
                    MediaStore.Audio.Media.DISPLAY_NAME,
                    MediaStore.Audio.Media.SIZE
            };
            String sel = MediaStore.Audio.Media.IS_MUSIC + " != 0 OR " + MediaStore.Audio.Media.MIME_TYPE + " LIKE 'audio/%'";
            try (android.database.Cursor c = cr.query(base, proj, sel, null, MediaStore.Audio.Media.TITLE + " COLLATE NOCASE ASC")) {
                if (c != null) while (c.moveToNext()) {
                    long mediaId = c.getLong(c.getColumnIndexOrThrow(MediaStore.Audio.Media._ID));
                    String key = String.valueOf(mediaId);
                    if (!seen.add(key)) continue;
                    long albumId = c.getLong(c.getColumnIndexOrThrow(MediaStore.Audio.Media.ALBUM_ID));
                    String title = c.getString(c.getColumnIndexOrThrow(MediaStore.Audio.Media.TITLE));
                    String artist = c.getString(c.getColumnIndexOrThrow(MediaStore.Audio.Media.ARTIST));
                    String album = c.getString(c.getColumnIndexOrThrow(MediaStore.Audio.Media.ALBUM));
                    String mime = c.getString(c.getColumnIndexOrThrow(MediaStore.Audio.Media.MIME_TYPE));
                    String display = c.getString(c.getColumnIndexOrThrow(MediaStore.Audio.Media.DISPLAY_NAME));
                    long dur = c.getLong(c.getColumnIndexOrThrow(MediaStore.Audio.Media.DURATION));
                    long size = c.getLong(c.getColumnIndexOrThrow(MediaStore.Audio.Media.SIZE));
                    long jsId = 1_000_000_000L + mediaId;
                    JSONObject o = new JSONObject();
                    o.put("id", jsId);
                    o.put("rid", key);
                    o.put("t", title == null || title.isEmpty() ? (display == null ? "Tanpa judul" : display) : title);
                    o.put("a", artist == null || artist.isEmpty() ? "Unknown" : artist);
                    o.put("album", album == null ? "" : album);
                    o.put("dur", dur);
                    o.put("size", size);
                    o.put("mime", mime == null ? "audio/*" : mime);
                    o.put("u", ASSET_BASE + "/media/" + Uri.encode(key));
                    if (albumId >= 0) o.put("cover", ASSET_BASE + "/art/" + Uri.encode(String.valueOf(albumId)));
                    else o.put("cover", "");
                    tracks.put(o);
                }
            }
            out.put("ok", true); out.put("count", tracks.length()); out.put("tracks", tracks);
        } catch (Throwable e) {
            out.put("ok", false); out.put("error", e.getClass().getSimpleName() + ": " + e.getMessage());
        }
        return out.toString();
    }

    static Uri mediaUri(String rid) {
        return ContentUris.withAppendedId(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, Long.parseLong(rid));
    }

    static Uri albumArtUri(String albumId) {
        return Uri.parse("content://media/external/audio/albumart/" + albumId);
    }

    android.webkit.WebResourceResponse openMedia(String rid, String rangeHeader) {
        return MainActivity.openContent(activity.getContentResolver(), mediaUri(rid), rangeHeader);
    }

    android.webkit.WebResourceResponse openAlbumArt(String albumId) {
        return MainActivity.openContent(activity.getContentResolver(), albumArtUri(albumId), null);
    }

    @JavascriptInterface public void update(String title, String artist, String album, String cover, boolean playing, long posMs, long durMs) {
        MediaService.update(activity, title, artist, album, cover, playing, posMs, durMs);
    }

    @JavascriptInterface public void clear() { MediaService.clear(activity); }
}
