# Kawaii Music 2.0 — device audio + album support

This project is reconstructed from the supplied APK web UI and updated with a native Android bridge.

## What changed

- Automatically scans Android's indexed audio library through MediaStore after the user grants audio permission. No per-file manual import is needed.
- Supports Android 13+ `READ_MEDIA_AUDIO` and Android 12 and lower `READ_EXTERNAL_STORAGE`.
- Adds album metadata to the player/list and lets each track override title, artist, album, and album cover.
- Uses each track's cover in the in-app player and sends the cropped cover to the native media notification.
- Native notification includes track title, artist, album, cover, play/pause, previous/next, rewind, and close.
- Existing manual file import remains available for files that are not indexed by MediaStore.
- `content://` media is exposed to the WebView through a controlled `WebViewAssetLoader` URL with HTTP range support for seeking.

## GitHub build

The workflow is `.github/workflows/build.yml` and also copied to the repository root as `build.yml`. It installs Java 17 and Gradle 8.13, then produces `app/build/outputs/apk/debug/app-debug.apk`.

## Important platform limitation

Android's scoped-storage model means the automatic scan covers audio exposed by the system MediaStore. Files that have never been indexed by Android are still accessible through the existing manual file import path. The app does not bypass Android storage permissions.
